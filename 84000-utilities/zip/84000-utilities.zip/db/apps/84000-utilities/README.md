# 84000 Utilities

Utilities for data management and testing of 84000 data.

You can find out more about eXist at [exist-db.org](http://exist-db.org).
