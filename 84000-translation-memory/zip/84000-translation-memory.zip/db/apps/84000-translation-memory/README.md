# 84000 Translation Memory

Tool for creating Translation Memory from 84000 translations.

You can find out more about eXist at [exist-db.org](http://exist-db.org).
