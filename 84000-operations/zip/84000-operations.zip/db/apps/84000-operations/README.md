# 84000 Project Management

Tools for 84000 project management.

You can find out more about eXist at [exist-db.org](http://exist-db.org).
